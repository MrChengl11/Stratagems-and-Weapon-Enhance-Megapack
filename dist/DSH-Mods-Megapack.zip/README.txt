========================================================================
   Helldivers 2 - Stratagems & Weapon Enhance Megapack (FPS Fixed)
   绝地潜兵 2 - 战备与武器强化整合包 (掉帧彻底修复版)
========================================================================

【Included Mods / 包含模组】
1. Orbital Laser Free (轨道激光无限次使用 + 冷却缩短至180秒)
2. Double 380mm Barrage (380mm 轨道火力网数量翻倍)
3. Double Leveller (EAT-411 荡平者一次空投两根发射器)
4. Eagle Carpet Bomb (飞鹰地毯式空袭，借壳飞鹰110mm槽位)
5. Dominator Eruptor Round (JAR-5 主宰发射 R-36 爆裂铳弹丸)
6. Dominator Bolt Pistol Round (JAR-5 主宰发射 GP-31 爆弹手枪弹药)

【Key Performance Fixes / 性能与掉帧修复亮点】
- 彻底消除了原版每 10 分钟触发的 2,500 帧全量内存暴力重扫 (消灭帧率骤降一半持续40秒的元凶)。
- 维护扫描添加 2ms 硬时钟预算 (os.clock deadline)，杜绝单帧微卡顿。
- 安全退钩守卫 (Guarded Update Unhook)，不截断后续挂载的其他模组的 update 链。
- 稳态静默运行，取消频繁写盘。

【Installation Guide / 安装方法】
使用 HD2 Mod Manager (HD2MM) 或 Arsenal (推荐):
1. 确保已安装 Bingus Shared Loader v15 或更高版本。
2. 将本 ZIP 导入 HD2MM 或 Arsenal。
3. 在模组选项 (Options) 中勾选所需功能：
   - 勾选【全套整合】预设可一键开启全套战备 + 主宰武器；
   - 勾选【战备整合】预设可仅开启4款战备，不修改武器；
   - 或自由勾选【独立可选】条目进行组合搭配。
4. 点击 Purge，然后点击 Deploy，启动游戏即可。
========================================================================
